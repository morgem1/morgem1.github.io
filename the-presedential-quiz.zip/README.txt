A Pen created at CodePen.io. You can find this one at http://codepen.io/TrumpIo/pen/PbPgWN.

 By michael it is a quiz